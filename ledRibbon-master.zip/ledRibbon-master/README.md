# ledRibbon
Exploration of using a LED ribbon for Electric Offense
